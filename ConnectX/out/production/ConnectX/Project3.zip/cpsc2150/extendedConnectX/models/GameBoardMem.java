package cpsc2150.extendedConnectX.models;
import java.util.*;

public class GameBoardMem extends AbsGameBoard implements IGameBoard {
    private int numRows;
    private int numColumns;
    private int numToWin;

    private HashMap<Character, List<BoardPosition>> boardMap;

    public GameBoardMem(int NumRows, int NumColumns, int NumToWin){
        numRows = NumRows;
        numColumns = NumColumns;
        numToWin = NumToWin;

        boardMap = new HashMap<>();
    }

    @Override
    public int getNumRows(){return numRows;}

    @Override
    public int getNumColumns(){return numColumns;}

    @Override
    public int getNumToWin(){return numToWin;}

    @Override
    public void placeToken(char p, int c) {
        if(!boardMap.containsKey(p)){
            boardMap.putIfAbsent(p, new ArrayList<>());
        }

        for(int i = 0; i < getNumRows(); i++){
            if(whatsAtPos(new BoardPosition(i,c)) == ' '){
                boardMap.get(p).add(new BoardPosition(i,c));
                break;
            }
        }
    }
    @Override
    public char whatsAtPos(BoardPosition pos){
        for(HashMap.Entry<Character, List<BoardPosition>> userInput : boardMap.entrySet()){
            if((userInput.getValue()).contains(pos)){
                return userInput.getKey();
            }
        }
        return ' ';
    }

}
